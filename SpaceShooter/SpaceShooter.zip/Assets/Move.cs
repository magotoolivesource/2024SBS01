using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Move : MonoBehaviour
{
    void Start()
    {
        
    }

    public float MoveSpeed = 1f;
    void Update()
    {
        Vector3 temppos = this.transform.position;
        temppos.z += MoveSpeed * Time.deltaTime;
        this.transform.position = temppos;

        if( temppos.z > 15f)
        {
            GameObject.Destroy( this.gameObject );
        }
    }
}
