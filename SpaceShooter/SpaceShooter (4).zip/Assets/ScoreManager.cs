using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class ScoreManager : MonoBehaviour
{
    public TMP_Text m_LinkText;
    protected static int ScoreVal = 0;
    public static void AddScore()
    {
        ScoreVal += 1;
        Debug.Log($"���� : {ScoreVal} ");
    }
    void Update()
    {
        m_LinkText.text = $"Score:{ScoreVal}";
    }
}
